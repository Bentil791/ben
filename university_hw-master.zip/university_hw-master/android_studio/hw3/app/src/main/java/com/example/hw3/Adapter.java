package com.example.hw3;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {

    //ArrayList<String> values;
    ArrayList<Good> goods;

    public Adapter(ArrayList<Good> goods) {
        this.goods = goods;
    }

    public void shuffle() {
        Collections.shuffle(this.goods);
        this.notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_view, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.textView1.setText(goods.get(position).getName());
        holder.textView2.setText(goods.get(position).getDescription());
        holder.textView3.setText(goods.get(position).getPrice() + "$");
    }


    @Override
    public int getItemCount() {
        return goods.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textView1 = null;
        public TextView textView2 = null;
        public TextView textView3 = null;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textView1 = itemView.findViewById(R.id.text_list_item);
            textView2 = itemView.findViewById(R.id.text_list_item2);
            textView3 = itemView.findViewById(R.id.text_list_item3);
        }
    }
}
