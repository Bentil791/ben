package com.example.hw3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final RecyclerView recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        final Adapter adapter = new Adapter(generateFakeValues());
        recyclerView.setAdapter(adapter);

        Button shuffle = findViewById(R.id.shuffle);
        shuffle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adapter.shuffle();
            }
        });
    }


    private ArrayList<Good> generateFakeValues() {
        ArrayList<Good> values = new ArrayList<Good>();

        for (int i = 0; i < 100; i++) {
            values.add(new Good("Name " + i, "Description " + i, (i + 1) * 10));
        }
        return values;
    }
}
